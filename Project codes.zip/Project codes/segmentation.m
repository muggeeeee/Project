% Read the image
image = imread('coins.jpg');

% Convert the image to double precision
image = double(image);

% Smooth the image using a Gaussian filter
sigma = 2; % Standard deviation of Gaussian kernel (you may need to adjust this)
smoothed_image = imgaussfilt(image, sigma);

% Reshape the smoothed image into a 2D matrix (rows x columns, channels)
[m, n, p] = size(smoothed_image);
X = reshape(smoothed_image, m * n, p);

% Number of clusters (you may need to adjust this)
K = 2;

% Perform k-means clustering
[IDX, C] = kmeans(X, K);

% Reshape the index matrix back into the image dimensions
segmented_image = reshape(IDX, m, n);

% Display the original image and the segmented image
subplot(1,2,1), imshow(uint8(image));
title('Original Image');
subplot(1,2,2), imshow(segmented_image, []);
title('Segmented Image');

% Display the cluster centers
disp('Cluster Centers:');
disp(C);

