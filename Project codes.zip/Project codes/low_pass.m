% Read the input image
img = imread('flower.jpg');

% Convert the image to grayscale
img = rgb2gray(img);

% Compute the Fourier transform of the image
F = fft2(double(img));

% Shift the zero frequency component to the center
F_shifted = fftshift(F);

% Define the dimensions of the image
[M, N] = size(img);
% Define cutoff frequency for the low-pass filter
cutoff_frequency = 150;

% Create a meshgrid to represent frequency space
[X, Y] = meshgrid(1:N, 1:M);
% Compute distance from the center for each pixel
D = sqrt((X - N/2).^2 + (Y - M/2).^2);

% Define the low-pass filter
H = double(D <= cutoff_frequency);

% Apply the filter to the shifted Fourier transform
F_filtered = F_shifted .* H;

% Shift the zero frequency component back to the corners
F_filtered_shifted = ifftshift(F_filtered);

% Compute the inverse Fourier transform to get the filtered image
img_filtered = real(ifft2(F_filtered_shifted));

% Display original and filtered images
figure;
subplot(2, 2, 1);
imshow(uint8(img));
title('Original Image');
subplot(2, 2, 2);
imshow(log(abs(F_shifted) + 1), []);
title('Original Frequency Domain');

subplot(2, 2, 3);
imshow(uint8(img_filtered));
title('Filtered Image');
subplot(2, 2, 4);
imshow(log(abs(F_filtered_shifted) + 1), []);
title('Filtered Frequency Domain');
