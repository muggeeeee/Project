% Read the image
originalImage = imread('car.jpeg');

% Define the scale factor for interpolation
scaleFactor = 0.3;

% Calculate the dimensions of the original and scaled images
[height, width, ~] = size(originalImage);
newHeight = round(height * scaleFactor);
newWidth = round(width * scaleFactor);

% Initialize the new images with zeros
newImageNN = zeros(newHeight, newWidth, 3, 'uint8');
newImageBilinear = zeros(newHeight, newWidth, 3, 'uint8');

% Nearest Neighbor Interpolation
for i = 1:newHeight
    for j = 1:newWidth
        % Calculate the corresponding position in the original image
        x = min(round(i / scaleFactor), height);
        y = min(round(j / scaleFactor), width);
        
        % Assign the pixel value from the original image to the new image
        newImageNN(i, j, :) = originalImage(x, y, :);
    end
end

% Bilinear Interpolation
for i = 1:newHeight
    for j = 1:newWidth
        % Calculate the corresponding position in the original image
        x = (i - 0.5) / scaleFactor + 0.5;
        y = (j - 0.5) / scaleFactor + 0.5;
        
        % Calculate the four nearest neighbor pixels in the original image
        x1 = max(floor(x), 1);
        x2 = min(x1 + 1, height);
        y1 = max(floor(y), 1);
        y2 = min(y1 + 1, width);
        
        % Calculate the interpolation weights
        dx = x - x1;
        dy = y - y1;
        
        % Perform bilinear interpolation for each color channel
        for k = 1:3
            newImageBilinear(i, j, k) = uint8((1 - dx) * (1 - dy) * double(originalImage(x1, y1, k)) + ...
                                               dx * (1 - dy) * double(originalImage(x2, y1, k)) + ...
                                               (1 - dx) * dy * double(originalImage(x1, y2, k)) + ...
                                               dx * dy * double(originalImage(x2, y2, k)));
        end
    end
end

% Display the original and nearest neighbor interpolation images
figure;
subplot(1, 2, 1);
imshow(originalImage);
title('Original Image');
subplot(1, 2, 2);
imshow(newImageNN);
title('Nearest Neighbor Interpolation');

% Display the original and bilinear interpolation images
figure;
subplot(1, 2, 1);
imshow(originalImage);
title('Original Image');
subplot(1, 2, 2);
imshow(newImageBilinear);
title('Bilinear Interpolation');
