% Read the image
original_image = imread('lighthouse.jpg');

% Convert the image to grayscale
gray_image = rgb2gray(original_image);

% Compute histogram of the input image using imhist
[num_pixels, gray_levels] = imhist(gray_image);
disp(num_pixels)

% Compute cumulative distribution function (CDF)
cdf = cumsum(num_pixels) / sum(num_pixels);

% Scale the CDF to range [0, 1] and map it to [0, 255]
scaled_cdf = uint8(255 * cdf);

% Initialize the equalized image
equalized_image = zeros(size(gray_image), 'uint8');

% Perform histogram equalization
for i = 1:numel(gray_levels)
    equalized_image(gray_image == gray_levels(i)) = scaled_cdf(gray_levels(i) + 1); % Adding 1 to handle zero-based indexing
end

% Compute histogram of the equalized image using imhist
[equalized_num_pixels, equalized_gray_levels] = imhist(equalized_image);

% Compute manual histogram equalization using the equalized histogram
manual_equalized_image = histeq(gray_image, equalized_num_pixels);

% Display the original and equalized images
figure;
subplot(2, 3, 1);
imshow(gray_image);
title('Original Image');

subplot(2, 3, 2);
imshow(equalized_image);
title('Equalized Image (Manual)');

subplot(2, 3, 3);
imshow(manual_equalized_image);
title('Equalized Image (Using histeq)');

% Show histograms using imhist
subplot(2, 3, 4);
imhist(gray_image);
title('Original Image Histogram');
xlabel('Pixel Intensity');
ylabel('Frequency');

subplot(2, 3, 5);
imhist(equalized_image);
title('Equalized Image Histogram (Manual)');
xlabel('Pixel Intensity');
ylabel('Frequency');

subplot(2, 3, 6);
imhist(manual_equalized_image);
title('Equalized Image Histogram (Using histeq)');
xlabel('Pixel Intensity');
ylabel('Frequency');
