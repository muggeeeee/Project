% Read the image
originalImage = imread('lighthouse.jpg');

% Convert the image to grayscale using rgb2gray
grayImage_rgb2gray = rgb2gray(originalImage);

% Get the dimensions of the image
[rows, cols, ~] = size(originalImage);

% Convert the image to grayscale using luminosity formula
grayImage_manual = zeros(rows, cols);
for i = 1:rows
    for j = 1:cols
        % Get RGB values
        R = originalImage(i, j, 1);
        G = originalImage(i, j, 2);
        B = originalImage(i, j, 3);
        
        % Compute luminosity
        luminosity = 0.2126 * R + 0.7152 * G + 0.0722 * B;
        
        % Set grayscale pixel value
        grayImage_manual(i, j) = luminosity;
    end
end

% Convert the image to grayscale by averaging RGB values
grayImage_averaging = zeros(rows, cols);
for i = 1:rows
    for j = 1:cols
        % Get RGB values
        R = double(originalImage(i, j, 1));
        G = double(originalImage(i, j, 2));
        B = double(originalImage(i, j, 3));
        
        % Compute average of RGB values
        avg_gray = (R + G + B) / 3;
        
        % Set grayscale pixel value
        grayImage_averaging(i, j) = avg_gray;
    end
end

% Display the original and grayscale images
figure;

subplot(2, 2, 1);
imshow(originalImage);
title('Original Image');

subplot(2, 2, 2);
imshow(grayImage_rgb2gray);
title('Grayscale Image (rgb2gray)');

subplot(2, 2, 3);
imshow(uint8(grayImage_manual)); % Convert to uint8 for display
title('Grayscale Image (Manual)');

subplot(2, 2, 4);
imshow(uint8(grayImage_averaging)); % Convert to uint8 for display
title('Grayscale Image (Averaging)');

% Calculate the average pixel value of the first gray image
averagePixelValue_grayImage1 = mean(grayImage_rgb2gray(:));

% Calculate the average pixel value of the second gray image
averagePixelValue_grayImage2 = mean(grayImage_manual(:));

% Calculate the average pixel value of the third gray image
averagePixelValue_grayImage3 = mean(grayImage_averaging(:));

% Display the results
disp(['Average Pixel Value of Gray Image using rgb2gray: ', num2str(averagePixelValue_grayImage1)]);
disp(['Average Pixel Value of Gray Image using luminosity formula: ', num2str(averagePixelValue_grayImage2)]);
disp(['Average Pixel Value of Gray Image using averaging RGB values: ', num2str(averagePixelValue_grayImage3)]);
