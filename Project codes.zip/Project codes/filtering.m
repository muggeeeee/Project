% Read the input image
inputImage = imread('car.jpeg');
inputImage = double(inputImage); % Convert to double for mathematical operations

% Define filter kernels

% Smoothing Filter (Gaussian)
sigma = 2;
kernelSize = 2*ceil(3*sigma) + 1;
gaussianKernel = fspecial('gaussian', kernelSize, sigma);

% Sharpening Filter (Laplacian)
laplacianKernel = [0 -1 0; -1 4 -1; 0 -1 0];

% Edge Detection Filters (Sobel)
sobelHorizontalKernel = [-1 0 1; -2 0 2; -1 0 1];
sobelVerticalKernel = [-1 -2 -1; 0 0 0; 1 2 1];

% Perform convolution

% Smoothing
smoothedImage = zeros(size(inputImage));
for i = 1:size(inputImage, 3)
    smoothedImage(:, :, i) = conv2(inputImage(:, :, i), gaussianKernel, 'same');
end

% Sharpening
sharpenedImage = zeros(size(inputImage));
for i = 1:size(inputImage, 3)
    % Apply Laplacian kernel with a smaller scaling factor
    sharpenedImage(:, :, i) = inputImage(:, :, i) + 0.25 * conv2(inputImage(:, :, i), laplacianKernel, 'same');
end

% Edge Detection
horizontalEdgeImage = zeros(size(inputImage));
verticalEdgeImage = zeros(size(inputImage));
for i = 1:size(inputImage, 3)
    horizontalEdgeImage(:, :, i) = conv2(inputImage(:, :, i), sobelHorizontalKernel, 'same');
    verticalEdgeImage(:, :, i) = conv2(inputImage(:, :, i), sobelVerticalKernel, 'same');
end
edgeMagnitude = sqrt(horizontalEdgeImage.^2 + verticalEdgeImage.^2);

% Display the results
figure;
subplot(2, 3, 1), imshow(uint8(inputImage)), title('Original Image');
subplot(2, 3, 2), imshow(uint8(smoothedImage)), title('Smoothed Image');
subplot(2, 3, 3), imshow(uint8(sharpenedImage)), title('Sharpened Image');
subplot(2, 3, 4), imshow(uint8(horizontalEdgeImage)), title('Horizontal Edge Detection');
subplot(2, 3, 5), imshow(uint8(verticalEdgeImage)), title('Vertical Edge Detection');
subplot(2, 3, 6), imshow(uint8(edgeMagnitude)), title('Edge Magnitude');
