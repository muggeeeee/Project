% Read the car image
car_image = imread('car.jpeg');

% Convert the image to grayscale
gray_car_image = rgb2gray(car_image);

% Add salt and pepper noise to the grayscale image
noisy_car_image = imnoise(gray_car_image, 'salt & pepper', 0.05);

% Define window sizes to test
window_sizes = [3, 7];

% Display the original grayscale image and the noisy image
figure;
subplot(2,2,1), imshow(gray_car_image), title('Original Grayscale Image');
subplot(2,2,2), imshow(noisy_car_image), title('Noisy Image with Salt & Pepper Noise');

% Apply median filtering with different window sizes
for i = 1:length(window_sizes)
    window_size = window_sizes(i);
    % Get the size of the noisy image
    [rows, cols] = size(noisy_car_image);

    % Initialize the restored image
    restored_car_image = zeros(rows, cols);

    % Pad the noisy image
    padded_image = padarray(noisy_car_image, [(window_size-1)/2, (window_size-1)/2], 'replicate');

    % Apply median filtering
    for j = 1:rows
        for k = 1:cols
            % Extract the window from the padded image
            window = padded_image(j:j+window_size-1, k:k+window_size-1);
            % Flatten the window into a vector
            window_vector = window(:);
            % Sort the values in the window
            sorted_window = sort(window_vector);
            % Get the median value
            median_value = sorted_window(floor(numel(sorted_window)/2) + 1);
            % Assign the median value to the corresponding pixel in the output image
            restored_car_image(j, k) = median_value;
        end
    end

    % Display the restored image
    subplot(2,2,i+2), imshow(uint8(restored_car_image)), title(['Window Size: ', num2str(window_size)]);
end
